function Home() {
  return (
    <div className="container">
      <h1>Open-Contacts-v2</h1>
    </div>
  );
}
export default Home;
